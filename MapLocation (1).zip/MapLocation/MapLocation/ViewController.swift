//
//  ViewController.swift
//  MapLocation
//
//  Created by MacStudent on 2018-11-14.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController {
    
    @IBOutlet weak var MyMapView: MKMapView!
    let initiallocation=CLLocation(latitude: 43.6532, longitude: -79.3832)
    let regionRadius:CLLocationDistance=100000
    override func viewDidLoad() {
        
        super.viewDidLoad()

        let coordinateRegion=MKCoordinateRegionMakeWithDistance(initiallocation.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        self.MyMapView.setRegion(coordinateRegion, animated: true)
        let myAnnotation: MKPointAnnotation = MKPointAnnotation()
        myAnnotation.coordinate = CLLocationCoordinate2DMake(initiallocation.coordinate.latitude, initiallocation.coordinate.longitude);
        myAnnotation.title = "Toronto"
        myAnnotation.subtitle = "City Hall, King St. W"
        self.MyMapView.addAnnotation(myAnnotation)
        // Do any additional setup after loading the view, typically from a nib.
    
}

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

